DASHBOARD SAMSAT - VERSI GITHUB PAGES

CARA UPLOAD:
1. Ekstrak semua isi ZIP ini.
2. Buat/pilih repository GitHub.
3. Upload SELURUH file HTML di folder ini ke root repository (bukan file render.php).
4. Buka Settings > Pages.
5. Pada Build and deployment pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu Save.
7. Tunggu proses deploy, kemudian buka URL GitHub Pages.

CATATAN PENTING:
- Versi ini mengubah hasil PHP menjadi HTML statis agar dapat dijalankan GitHub Pages.
- Semua data yang ditampilkan adalah data yang tertanam di file dashboard saat konversi.
- GitHub Pages tidak menjalankan PHP atau MySQL; perubahan data harus dilakukan pada sumber lalu dibuat ulang/diunggah.
- Login admin/admin123 hanya simulasi sisi browser dan BUKAN keamanan. Siapa pun dapat melihat file HTML/JavaScript dan membuka halaman secara langsung.
- Jangan unggah data pajak atau informasi internal/rahasia ke repository publik. Gunakan repository private jika sesuai, namun GitHub Pages private memiliki batasan sesuai paket GitHub.
- File render.php tidak perlu diunggah.
